const navMenu = document.querySelector(".nav-menu");
const hamburger = document.querySelector(".hamburger");

hamburger.addEventListener("click", () => {
  hamburger.classList.toggle("open");
  navMenu.classList.toggle("open");
});


////////

let indexSlide = 1;
showSlides(indexSlide);

function plusSlides(n) {
  showSlides(indexSlide += n);
}

function currentSlide(n) {
  showSlides(indexSlide = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {indexSlide = 1}    
  if (n < 1) {indexSlide = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[indexSlide-1].style.display = "block";  
  dots[indexSlide-1].className += " active";
}
////////////



//////////

const tabs = document.querySelectorAll(".tabs li");
const tabsArray = Array.from(tabs); 
console.log(tabsArray);
const divs = document.querySelectorAll(".content > div");
const divsArray = Array.from(divs);

tabsArray.forEach((ele) => {
  ele.addEventListener("click", function (e) {
    console.log(ele);
    tabsArray.forEach((ele) => {
      ele.classList.remove("clive");
    });
    e.currentTarget.classList.add("clive");
    divsArray.forEach((div) => {
      div.style.display = "none";
    });
    console.log(e.currentTarget.dataset.cont);
    document.querySelector(e.currentTarget.dataset.cont).style.display= "contents";
  });
});





///////////
function defer(method) {
  if (window.jQuery)
    method();
  else
    setTimeout(function() {
      defer(method)
    }, 50);
}
defer(function() {
  (function($) {
    
    function doneResizing() {
      var totalScroll = $('.logo-slider-frame').scrollLeft();
      var itemWidth = $('.logo-slider-item').width();
      var difference = totalScroll % itemWidth;
      if ( difference !== 0 ) {
        $('.logo-slider-frame').animate({
          scrollLeft: '-=' + difference
        }, 500, function() {
          checkArrows();
        });
      }
    }
    
    function checkArrows() {
      var totalWidth = $('#logo-slider .logo-slider-item').length * $('.logo-slider-item').width();
      var frameWidth = $('.logo-slider-frame').width();
      var itemWidth = $('.logo-slider-item').width();
      var totalScroll = $('.logo-slider-frame').scrollLeft();
      
    }
    
    $('.arrow').on('click', function() {
      var $this = $(this),
        width = $('.logo-slider-item').width(),
        speed = 500;
      if ($this.hasClass('prev')) {
        $('.logo-slider-frame').animate({
          scrollLeft: '-=' + width
        }, speed, function() {
          checkArrows();
        });
      } else if ($this.hasClass('next')) {
        $('.logo-slider-frame').animate({
          scrollLeft: '+=' + width
        }, speed, function() {
          checkArrows();
        });
      }
    });
    
    $(window).on("load resize", function() {
      checkArrows();
      $('#logo-slider .logo-slider-item').each(function(i) {
        var $this = $(this),
          left = $this.width() * i;
        $this.css({
          left: left
        })
      }); 
    }); 
    
    var resizeId;
    $(window).resize(function() {
        clearTimeout(resizeId);
        resizeId = setTimeout(doneResizing, 500);
    });
    
  })(jQuery);
});



/////


let scrollToBottom = document.querySelector('#scroll-to-bottom');

scrollToBottom.addEventListener('click', function () {

    document.getElementById('page-bottom').scrollIntoView();
})
                  

